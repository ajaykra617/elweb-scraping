import './globals.css';
import React from 'react';
import Link from 'next/link';

export const metadata = {
  title: 'elweb Dashboard',
  description: 'Elweb scraping dashboard',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <div className="min-h-screen flex">
          <aside className="w-64 bg-white border-r p-4">
            <h2 className="text-xl font-semibold mb-4">elweb</h2>
            <nav className="space-y-2">
              <Link href="/jobs" className="block px-3 py-2 rounded hover:bg-slate-100">Jobs</Link>
              <Link href="/new-job" className="block px-3 py-2 rounded hover:bg-slate-100">New Job</Link>
              <Link href="/auth/login" className="block px-3 py-2 rounded hover:bg-slate-100">Login</Link>
            </nav>
          </aside>
          <main className="flex-1 p-6">
            {children}
          </main>
        </div>
      </body>
    </html>
  );
}
