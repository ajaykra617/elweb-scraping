'use client';
import React, { useEffect, useState } from 'react';
import LogViewer from '../../../components/LogViewer';

export default function JobDetail({ params }: { params: { id: string } }) {
  const { id } = params;
  const [job, setJob] = useState<any>(null);

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000'}/jobs/${id}`, { credentials: 'include' });
        const data = await res.json();
        setJob(data);
      } catch (e) {}
    })();
  }, [id]);

  return (
    <div>
      <h1 className="text-2xl mb-4">Job {id}</h1>
      <div className="mb-4">
        <strong>Status:</strong> {job?.status || 'unknown'}
      </div>
      <div>
        <h2 className="text-lg mb-2">Live Logs</h2>
        <LogViewer jobId={id} />
      </div>
    </div>
  );
}
