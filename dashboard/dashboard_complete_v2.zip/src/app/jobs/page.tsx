'use client';
import React, { useEffect, useState } from 'react';
import { apiGet } from '../../lib/api';

type Job = { id: string | number; status: string; createdAt?: string; };

export default function JobsPage() {
  const [jobs, setJobs] = useState<Job[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    (async () => {
      try {
        const data = await apiGet('/jobs'); // adjust if your backend has /jobs/user/:id
        if (data.error) { setError(data.error); setLoading(false); return; }
        setJobs(Array.isArray(data) ? data : []);
      } catch (e: any) {
        setError(e.message || 'Failed');
      } finally { setLoading(false); }
    })();
  }, []);

  return (
    <div>
      <h1 className="text-2xl mb-4">Jobs</h1>
      {loading && <div>Loading...</div>}
      {error && <div className="text-red-600">{error}</div>}
      <div className="space-y-2">
        {jobs.map(j => (
          <div key={String(j.id)} className="bg-white p-3 rounded shadow">
            <div className="flex justify-between">
              <div>Job {String(j.id)}</div>
              <div className="text-sm">{j.status}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
