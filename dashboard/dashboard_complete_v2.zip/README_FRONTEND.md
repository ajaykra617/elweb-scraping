This dashboard uses httpOnly cookies for auth. Ensure backend sets cookie on /auth/login and /auth/signup. Run `npm install` then `npm run dev`.
